#!/usr/bin/bash

cd /
cd /sys/class/gpio
echo '17' > unexport
#echo '17' > /sys/class/gpio/unexportx
