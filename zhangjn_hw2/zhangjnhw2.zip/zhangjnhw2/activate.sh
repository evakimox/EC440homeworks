#!/usr/bin/bash

cd /
cd /sys/class/gpio

echo '17' > export

cd gpio17

echo 'out' > direction


